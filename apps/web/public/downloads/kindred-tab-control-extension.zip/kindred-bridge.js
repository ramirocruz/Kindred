
(()=>{
if(globalThis.__kindredQuietBridge)return;globalThis.__kindredQuietBridge=true;
const pending=new Map(),channel='kindred-tab-control';
const post=(type,payload)=>window.postMessage({channel,type,payload},location.origin);
const requestStatus=()=>chrome.runtime.sendMessage({type:'quiet-status'},r=>{if(!chrome.runtime.lastError)post('bridge-status',r);});
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(sender.id!==chrome.runtime.id)return;
  if(m.type==='quiet-stop'){post('quiet-stop',{token:m.token});post('bridge-status',{connected:false,version:'0.8.0'});reply({ok:true});return;}
  if(!['quiet-prepare','quiet-start'].includes(m.type))return;
  const id=crypto.randomUUID(),timer=setTimeout(()=>{pending.delete(id);reply({ok:false,message:'Kindred did not respond. Refresh the room and try again.'});},10000);
  pending.set(id,{reply,timer});post(m.type,{...m,id});return true;
});
window.addEventListener('message',e=>{
  if(e.source!==window||e.origin!==location.origin||e.data?.channel!==channel)return;
  const {type,payload}=e.data;
  if(type==='quiet-response'){const p=pending.get(payload?.id);if(p){clearTimeout(p.timer);pending.delete(payload.id);p.reply(payload);}return;}
  if(type==='status-request'){requestStatus();return;}
  if(type==='quiet-command')chrome.runtime.sendMessage({type:'quiet-control',payload},r=>post('quiet-result',{id:payload?.id,...(chrome.runtime.lastError?{ok:false,message:chrome.runtime.lastError.message}:r)}));
  if(type==='unlink-tab')chrome.runtime.sendMessage({type:'quiet-unlink'},r=>{if(chrome.runtime.lastError)post('quiet-error',{message:chrome.runtime.lastError.message});else if(!r?.ok)post('quiet-error',r);else requestStatus();});
});
requestStatus();
})();
