# Kindred Tab Control v0.8.0

## Update
Stop/unlink existing sharing. Replace the installed unpacked extension folder with this release, Reload on Chrome Extensions and accept new permissions, then refresh Kindred. Reloading old files does not download an update.

## GDrive playback
Open/start the Drive video. In the extension choose GDrive playback, select your connected Kindred room, then Share GDrive tab. Everyone can play/pause/seek using room controls. Enable tab audio below chat on presenter and guests. No debugger is attached in this mode; Chrome retains capture indicators.

## Screen share
Non-interactive is default in Kindred: choose Screen share → Choose what to share. No extension is needed; others watch/listen only. Chrome may show sharing indicators.

For interactive mode, on the source tab select Interactive screen in the extension and Link interactive tab. Chrome displays its debugger warning. In Kindred's Screen share segment enable Interactive control, then share that exact browser tab. Everyone can click, drag, scroll and type into that page. Share only a tab you trust room members to operate. Native browser/OS dialogs cannot be controlled. Other extensions may prevent debugger attachment; use non-interactive mode or a separate profile. Stop and re-share to change mode.

Stop/unlink from the extension or linked-tab dialog in Kindred. Stop sharing revokes input. Unlink before switching extension modes.

## Limits
Only the presenter needs the extension. Chrome 116+ desktop. GDrive searches allowed Drive/Docs/googleusercontent and youtube.googleapis.com player frames, skipping foreign extension frames. Unsupported/ambiguous players fail explicitly. No DRM bypass. Interactive mode uses debugger permission only after explicit linking.

Tested: isolated real-browser GDrive and interactive presenter/guest fixtures, audio signal, source control and unlink. Actual authenticated Drive playback and different-device networking remain unverified. No promise all browser-owned indicators disappear.
