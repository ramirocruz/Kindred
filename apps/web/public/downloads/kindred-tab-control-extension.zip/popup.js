let source;
const status=document.querySelector('#status'),button=document.querySelector('#link'),mode=document.querySelector('#mode'),room=document.querySelector('#room');
function refreshMode(){const interactive=mode.value==='interactive';room.disabled=interactive;button.disabled=!interactive&&!room.options.length;button.textContent=interactive?'Link interactive tab':'Share GDrive tab';document.querySelector('#modeHelp').textContent=interactive?'Everyone can click and type in your shared tab. Chrome shows a debugger warning. After linking, use Screen share in Kindred and choose this same tab.':'GDrive: everyone can play, pause and seek. No debugger attachment.';}
(async()=>{
 [source]=await chrome.tabs.query({active:true,currentWindow:true});
 const rooms=(await chrome.tabs.query({url:'https://kindred.cheekyscout32.chatgpt.site/*'})).filter(t=>new URL(t.url).hash.includes('~'));
 for(const tab of rooms){const o=document.createElement('option');o.value=tab.id;o.textContent=tab.title+' · '+new URL(tab.url).hash.slice(1).split('~')[0];room.append(o);}
 refreshMode();status.textContent='Choose a mode. Stop/unlink before changing modes.';
})().catch(e=>status.textContent=e.message);
mode.onchange=refreshMode;
button.onclick=async()=>{
 button.disabled=true;status.textContent='Connecting…';
 try{const r=await chrome.runtime.sendMessage(mode.value==='interactive'?{type:'kindred-link-tab',tabId:source?.id}:{type:'quiet-begin',tabId:source?.id,roomTabId:Number(room.value)});status.textContent=r.ok?(mode.value==='interactive'?'Linked. Return to Screen share, enable interaction and share this exact tab.':'Sharing in GDrive. Return to Kindred.'):r.message;}catch(e){status.textContent=e.message;}finally{refreshMode();}
};
document.querySelector('#unlink').onclick=async()=>{try{await chrome.runtime.sendMessage({type:'quiet-stop'});await chrome.runtime.sendMessage({type:'kindred-unlink-tab'});status.textContent='Stopped and unlinked.';}catch(e){status.textContent=e.message;}};
