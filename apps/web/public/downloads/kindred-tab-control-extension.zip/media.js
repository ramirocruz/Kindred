// Serialized by executeScript; only operates on accessible HTML media, never arbitrary JS.
export async function mediaOperation(command, targetId) {
 try {
  const key='__kindredQuietMedia';
  const registry=globalThis[key]||(globalThis[key]=new Map());
  const scan=root=>{
    const found=[...root.querySelectorAll('video')];
    for(const element of root.querySelectorAll('*'))if(element.shadowRoot)found.push(...scan(element.shadowRoot));
    return found;
  };
  if(command.action==='discover'){
    for(const [id,video] of registry)if(!video.isConnected)registry.delete(id);
    return scan(document).filter(v=>{const r=v.getBoundingClientRect();return r.width>0&&r.height>0&&v.readyState>=1;}).map(video=>{
      let id=[...registry].find(([,v])=>v===video)?.[0];if(!id){id=crypto.randomUUID();registry.set(id,video);}
      const r=video.getBoundingClientRect();return {id,area:r.width*r.height,duration:Number.isFinite(video.duration)?video.duration:null};
    });
  }
  const video=registry.get(targetId);
  if(!video?.isConnected)throw Error('The player changed. Stop sharing and link it again.');
  if(!['state','play','pause','seek'].includes(command.action))throw Error('Unsupported media command.');
  if(command.action==='play'){
    let timer;try{await Promise.race([video.play(),new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('The player did not start. Press Play on the Drive tab once, then try again.')),5000))]);}finally{clearTimeout(timer);}
  }
  if(command.action==='pause')video.pause();
  if(command.action==='seek'){
    if(!Number.isFinite(command.time)||command.time<0)throw Error('Invalid seek time.');
    if(!Number.isFinite(video.duration)||video.duration<=0)throw Error('This media has no seekable timeline.');
    const target=Math.min(command.time,Math.max(0,video.duration-.05));
    if(![...Array(video.seekable.length).keys()].some(i=>target>=video.seekable.start(i)&&target<=video.seekable.end(i)))throw Error('That point is not currently seekable.');
    await new Promise((resolve,reject)=>{
      const done=()=>{clearTimeout(timer);video.removeEventListener('seeked',done);resolve();};
      const timer=setTimeout(()=>{video.removeEventListener('seeked',done);reject(Error('The player did not finish seeking.'));},5000);
      video.addEventListener('seeked',done);video.currentTime=target;
      if(!video.seeking)done();
    });
  }
  return {time:video.currentTime,duration:Number.isFinite(video.duration)?video.duration:null,paused:video.paused};
 }catch(error){return {failure:error.message||'The source player rejected playback.'};}
}
