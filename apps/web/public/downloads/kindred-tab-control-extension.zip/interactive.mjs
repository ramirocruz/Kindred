// Only fixed input operations are accepted; room peers cannot send CDP methods or JavaScript.
export const KINDRED_ORIGIN = 'https://kindred.cheekyscout32.chatgpt.site';
export class InteractiveTab {
  constructor(api) { this.api=api; this.link=null; this.queue=Promise.resolve(); }
  async restore() { if(!this.link) this.link=(await this.api.storage.session.get('interactiveLink')).interactiveLink||null; return this.link; }
  async save() { await this.api.storage.session.set({interactiveLink:this.link}); }
  async attach(tabId) {
    await this.unlink();
    await this.api.debugger.attach({tabId},'1.3');
    this.link={tabId,handle:crypto.randomUUID(),roomTabId:null,room:null};
    try {
      const config={handle:this.link.handle,exposeOrigin:true,permittedOrigins:[KINDRED_ORIGIN]};
      const result=await this.api.debugger.sendCommand({tabId},'Runtime.evaluate',{expression:`navigator.mediaDevices.setCaptureHandleConfig(${JSON.stringify(config)})`,returnByValue:true});
      if(result.exceptionDetails) throw new Error('This tab cannot identify itself for interactive sharing.');
      await this.save();
    } catch(error) { await this.unlink(); throw error; }
  }
  async unlink() {
    await this.restore(); const old=this.link; this.link=null;
    await this.api.storage.session.remove('interactiveLink');
    if(old) await this.api.debugger.detach({tabId:old.tabId}).catch(()=>{});
  }
  async arm(senderTabId, room, handle) {
    const link=await this.restore();
    if(!link||!handle||handle!==link.handle) throw new Error('Share the exact tab linked in the extension. Stop sharing, link that tab, then share it again.');
    if(typeof room!=='string'||!room||room.length>200) throw new Error('Open a room first.');
    link.roomTabId=senderTabId; link.room=room; await this.save();
    return {ok:true};
  }
  async disarm(senderTabId) {
    const link=await this.restore();
    if(link?.roomTabId===senderTabId){link.roomTabId=null;link.room=null;await this.save();}
  }
  input(senderTabId, room, payload) {
    const next=this.queue.then(()=>this.dispatch(senderTabId,room,payload));
    this.queue=next.catch(()=>{});return next;
  }
  async dispatch(senderTabId, room, p) {
    const link=await this.restore();
    if(!link||link.roomTabId!==senderTabId||link.room!==room) throw new Error('Interactive sharing is not enabled for this room.');
    const target={tabId:link.tabId};
    const call=(method,args)=>this.api.debugger.sendCommand(target,method,args);
    const allowed=['click','drag','move','wheel','text','key'];
    if(!p||!allowed.includes(p.action)) throw new Error('Unsupported input.');
    if(p.action==='text') {
      if(typeof p.text!=='string'||p.text.length>500) throw new Error('Text is too long.');
      await call('Input.insertText',{text:p.text}); return {ok:true};
    }
    if(p.action==='key') {
      const codes={Enter:13,Backspace:8,Delete:46,Tab:9,Escape:27,ArrowLeft:37,ArrowUp:38,ArrowRight:39,ArrowDown:40,Home:36,End:35,PageUp:33,PageDown:34,' ':32};
      if(!Object.hasOwn(codes,p.key)) throw new Error('Unsupported key.');
      const args={key:p.key,windowsVirtualKeyCode:codes[p.key],modifiers:p.shift?8:0};
      await call('Input.dispatchKeyEvent',{...args,type:'keyDown'});
      await call('Input.dispatchKeyEvent',{...args,type:'keyUp'}); return {ok:true};
    }
    const {cssVisualViewport:v}=await call('Page.getLayoutMetrics',{});
    if(!v?.clientWidth||!v?.clientHeight) throw new Error('The linked tab has no visible page.');
    const point=q=>{
      if(!q||!Number.isFinite(q.x)||!Number.isFinite(q.y)||q.x<0||q.x>1||q.y<0||q.y>1)throw new Error('Pointer is outside the shared page.');
      return {x:Math.min(v.clientWidth-1,q.x*v.clientWidth),y:Math.min(v.clientHeight-1,q.y*v.clientHeight)};
    };
    const mouse=args=>call('Input.dispatchMouseEvent',args);
    if(p.action==='wheel') {
      if(!Number.isFinite(p.deltaX)||!Number.isFinite(p.deltaY))throw new Error('Invalid scroll.');
      await mouse({...point(p),type:'mouseWheel',deltaX:Math.max(-1200,Math.min(1200,p.deltaX)),deltaY:Math.max(-1200,Math.min(1200,p.deltaY))});
    } else if(p.action==='move') await mouse({...point(p),type:'mouseMoved',button:'none'});
    else {
      const path=p.action==='drag'?p.points:[p];
      if(!Array.isArray(path)||!path.length||path.length>64)throw new Error('Invalid drag.');
      const points=path.map(point), count=p.double?2:1;
      await mouse({...points[0],type:'mouseMoved',button:'none'});
      try {
        await mouse({...points[0],type:'mousePressed',button:'left',buttons:1,clickCount:count});
        for(const q of points.slice(1))await mouse({...q,type:'mouseMoved',button:'left',buttons:1});
      } finally {await mouse({...points.at(-1),type:'mouseReleased',button:'left',buttons:0,clickCount:count});}
    }
    return {ok:true};
  }
}
