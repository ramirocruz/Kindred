import './interactive-background.js';

import {mediaOperation} from './media.js';
const ORIGIN='https://kindred.cheekyscout32.chatgpt.site';
const sourceAllowed=url=>{try{const u=new URL(url);return u.protocol==='https:'&&(u.hostname==='drive.google.com'||u.hostname==='docs.google.com'||u.hostname.endsWith('.googleusercontent.com'));}catch{return false;}};
const frameAllowed=url=>sourceAllowed(url)||(()=>{try{return new URL(url).origin==='https://youtube.googleapis.com';}catch{return false;}})();
let queue=Promise.resolve(),queued=0;
const session=async()=> (await chrome.storage.session.get('quietSession')).quietSession;
const roomSender=s=>{try{return s.frameId===0&&new URL(s.url).origin===ORIGIN;}catch{return false;}};
async function stop(){
  const s=await session();await chrome.storage.session.remove('quietSession');
  if(s)await chrome.tabs.sendMessage(s.roomTabId,{type:'quiet-stop',token:s.token},{frameId:0}).catch(()=>{});
  return {ok:true,connected:false,version:'0.8.0'};
}
async function discover(tabId){
  const frames=(await chrome.webNavigation.getAllFrames({tabId})).filter(f=>frameAllowed(f.url));
  const results=await Promise.all(frames.map(async frame=>{
    try{return (await chrome.scripting.executeScript({target:{tabId,frameIds:[frame.frameId]},func:mediaOperation,args:[{action:'discover'}]})).flatMap(r=>(Array.isArray(r.result)?r.result:[]).map(v=>({...v,frameId:frame.frameId,documentId:r.documentId})));}catch{return [];}
  }));
  const players=results.flat();
  if(!players.length)throw Error('No accessible video found. Open and start the Drive video first. This player may not be supported.');
  if(players.length>1)throw Error('More than one visible video found. Close the other players before sharing.');
  return players[0];
}
async function begin(tabId,roomTabId){
  if((await chrome.storage.session.get('interactiveLink')).interactiveLink)throw Error('Unlink the interactive tab before starting GDrive.');
  if(await session())throw Error('Stop your current share before starting another one.');
  const source=await chrome.tabs.get(tabId),room=await chrome.tabs.get(roomTabId);
  if(!sourceAllowed(source.url)||new URL(room.url).origin!==ORIGIN)throw Error('Open your Drive video and select a Kindred room.');
  const info=await chrome.tabs.sendMessage(roomTabId,{type:'quiet-prepare'},{frameId:0});
  if(!info?.ok||!info.room||info.room!==new URL(room.url).hash.slice(1).split('~')[0])throw Error(info?.message||'Create or join a ready room first, then refresh Kindred.');
  const roomFrame=await chrome.webNavigation.getFrame({tabId:roomTabId,frameId:0});
  const player=await discover(tabId);
  const streamId=await chrome.tabCapture.getMediaStreamId({targetTabId:tabId,consumerTabId:roomTabId});
  const s={tabId,roomTabId,roomDocumentId:roomFrame.documentId,room:info.room,player,title:source.title,token:crypto.randomUUID()};
  await chrome.storage.session.set({quietSession:s});
  try{
    const result=await chrome.tabs.sendMessage(roomTabId,{type:'quiet-start',streamId,token:s.token,room:s.room,title:s.title},{frameId:0});
    if(!result?.ok)throw Error(result?.message||'Kindred could not start the shared stream.');
    return {ok:true,title:s.title,version:'0.8.0'};
  }catch(error){await stop();throw error;}
}
async function control(sender,p){
  const s=await session();
  if(!s||!roomSender(sender)||sender.tab?.id!==s.roomTabId||sender.documentId!==s.roomDocumentId||p.token!==s.token||p.room!==s.room)throw Error('This room has no active shared tab.');
  if(p.action==='stop')return stop();
  if(!['state','play','pause','seek'].includes(p.action))throw Error('Unsupported playback command.');
  if(p.action==='seek'&&(!Number.isFinite(p.time)||p.time<0))throw Error('Invalid seek time.');
  const [result]=await chrome.scripting.executeScript({target:{tabId:s.tabId,documentIds:[s.player.documentId]},func:mediaOperation,args:[{action:p.action,time:p.time},s.player.id]});
  if(result?.error||result?.result?.failure)throw Error(result.result?.failure||result.error.message||'Source player rejected the action.');
  if(!result?.result)throw Error('No playback acknowledgement from the source. Stop and share the tab again.');
  return {ok:true,state:result.result};
}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(!m?.type?.startsWith('quiet-'))return;
  // Revocation must not wait behind a slow media request.
  const popup=sender.url===chrome.runtime.getURL('popup.html');
  if((popup&&m.type==='quiet-stop')||(roomSender(sender)&&m.type==='quiet-unlink')||(roomSender(sender)&&m.type==='quiet-control'&&m.payload?.action==='stop')){
    (async()=>{if(popup)return stop();if(m.type==='quiet-control')return control(sender,m.payload);const s=await session();if(s?.roomTabId!==sender.tab.id||s?.roomDocumentId!==sender.documentId)throw Error('Only the presenting room may unlink this tab.');return stop();})().then(reply,e=>reply({ok:false,message:e.message}));return true;
  }
  if(queued>=20){reply({ok:false,message:'Too many playback requests. Try again shortly.'});return;}
  queued++;
  const task=async()=>{
    if(sender.url===chrome.runtime.getURL('popup.html')){
      if(m.type==='quiet-begin')return begin(m.tabId,m.roomTabId);
      if(m.type==='quiet-stop')return stop();
      if(m.type==='quiet-status'){const s=await session();return {ok:true,connected:!!s,title:s?.title,version:'0.8.0'};}
    }
    if(roomSender(sender)){
      if(m.type==='quiet-control')return control(sender,m.payload||{});
      if(m.type==='quiet-status'){const s=await session();return {connected:!!s&&s.roomTabId===sender.tab.id&&s.roomDocumentId===sender.documentId,title:s?.roomTabId===sender.tab.id?s.title:'',version:'0.8.0'};}
      if(m.type==='quiet-unlink'){const s=await session();if(s?.roomTabId!==sender.tab.id||s?.roomDocumentId!==sender.documentId)throw Error('Only the presenting room may unlink this tab.');return stop();}
    }
    throw Error('Unauthorized request.');
  };
  const next=queue.then(task);queue=next.catch(()=>{});
  next.then(reply,error=>reply({ok:false,message:error.message})).finally(()=>queued--);return true;
});
async function revokeIf(test){try{const s=await session();if(s&&test(s))await stop();}catch{}}
chrome.tabs.onRemoved.addListener(id=>revokeIf(s=>id===s.tabId||id===s.roomTabId));
chrome.webNavigation.onCommitted.addListener(d=>revokeIf(s=>(d.tabId===s.roomTabId&&d.frameId===0)||(d.tabId===s.tabId&&(d.frameId===0||d.frameId===s.player.frameId))));
chrome.webNavigation.onReferenceFragmentUpdated.addListener(d=>revokeIf(s=>d.tabId===s.roomTabId&&new URL(d.url).hash.slice(1).split('~')[0]!==s.room));
chrome.tabCapture.onStatusChanged.addListener(info=>{
  if(['stopped','error'].includes(info.status))revokeIf(s=>s.tabId===info.tabId);
});
