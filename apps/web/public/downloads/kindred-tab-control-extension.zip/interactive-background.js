import {InteractiveTab, KINDRED_ORIGIN} from './interactive.mjs';
const interactive=new InteractiveTab(chrome);
let linkedTabId = null;
async function targetInfo(tabId) {
  const tab=await chrome.tabs.get(tabId);
  if(tab.url)return tab;
  const target=(await chrome.debugger.getTargets()).find(item=>item.tabId===tabId);
  return {...tab,url:target?.url,title:target?.title};
}

async function restoreLinkedTab() {
  if (Number.isInteger(linkedTabId)) return linkedTabId;
  const saved = await chrome.storage.session.get('linkedTabId');
  linkedTabId = Number.isInteger(saved.linkedTabId) ? saved.linkedTabId : null;
  return linkedTabId;
}

async function clearLinkedTab() {
  linkedTabId = null;
  await chrome.storage.session.remove('linkedTabId');
}

async function linkedStatus() {
  const tabId = await restoreLinkedTab();
  if (!Number.isInteger(tabId)) return { connected: false };
  try {
    const tab = await targetInfo(tabId);
    return { connected: true, tabId, title: tab.title || 'Linked tab' };
  } catch {
    await clearLinkedTab();
    return { connected: false };
  }
}

const KINDRED_TAB_QUERY = { url: ['https://kindred.cheekyscout32.chatgpt.site/*'] };

async function ensureKindredBridges() {
  const tabs = await chrome.tabs.query(KINDRED_TAB_QUERY);
  await Promise.all(tabs.map(tab => chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['interactive-bridge.js'] }).catch(() => undefined)));
  return tabs;
}

async function notifyKindredStatus(status) {
  if (!status) status = await linkedStatus();
  const tabs = await ensureKindredBridges();
  await Promise.all(tabs.map(tab => chrome.tabs.sendMessage(tab.id, { type: 'kindred-tab-bridge-status', payload: status }).catch(() => undefined)));
  return status;
}

async function linkTab(tabId) {
  if (!Number.isInteger(tabId)) return { ok: false, message: 'Open the tab you want to link, then try again.' };
  const tab = await targetInfo(tabId);
  if (!tab.url || !/^https?:/i.test(tab.url) || new URL(tab.url).origin===KINDRED_ORIGIN) return { ok: false, message: 'Open the Google Drive video tab, not the Kindred room, then link it.' };
  try {
    if((await chrome.storage.session.get('quietSession')).quietSession)throw Error('Stop GDrive sharing before linking an interactive tab.');
    await interactive.attach(tabId);
    linkedTabId = tabId;
    await chrome.storage.session.set({ linkedTabId: tabId });
    return { ok: true, ...(await notifyKindredStatus()) };
  } catch(error) {
    await interactive.unlink(); await clearLinkedTab(); await notifyKindredStatus({connected:false});
    return { ok: false, message: error.message || 'Chrome could not link this page.' };
  }
}

async function unlinkTab() {
  const status = await linkedStatus();
  await interactive.unlink();
  await clearLinkedTab();
  await notifyKindredStatus({ connected: false });
  return { ok: true, connected: false, title: status.title || '' };
}

async function sendToLinkedTab(command) {
  const status = await linkedStatus();
  if (!status.connected) return { ok: false, connected: false, message: 'Link the presenter tab first.' };
  try {
    const response = await chrome.tabs.sendMessage(status.tabId, { type: 'kindred-playback-command', payload: command });
    return { ...status, ok: Boolean(response?.ok), control: response || null };
  } catch {
    await clearLinkedTab();
    return { ok: false, connected: false, message: 'The linked tab was reloaded. Link it again to continue.' };
  }
}

async function tellKindredTabs(payload) {
  const tabs = await ensureKindredBridges();
  await Promise.all(tabs.map(tab => chrome.tabs.sendMessage(tab.id, { type: 'kindred-tab-event', payload }).catch(() => undefined)));
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.type?.startsWith('kindred-')) return undefined;
  (async () => {
    const popup=sender.url===chrome.runtime.getURL('popup.html');
    let room=false;try{room=new URL(sender.url).origin===KINDRED_ORIGIN&&sender.frameId===0;}catch{}
    if (message.type === 'kindred-link-tab' && popup) return linkTab(message.tabId);
    if(message.type==='kindred-interactive' && room){
      const p=message.payload||{};
      if(p.action==='arm')return interactive.arm(sender.tab.id,p.room,p.handle);
      if(p.action==='disarm'){const link=await interactive.restore();if(link?.roomTabId===sender.tab.id)await unlinkTab();return {ok:true};}
      return interactive.input(sender.tab.id,p.room,p.input);
    }
    if(!popup&&!room){
      if(message.type==='kindred-controller-event'&&sender.tab?.id===await restoreLinkedTab()){await tellKindredTabs(message.payload||{});return {ok:true};}
      return {ok:false,message:'This tab is not authorized.'};
    }
    if (message.type === 'kindred-bridge-status') return linkedStatus();
    if (message.type === 'kindred-unlink-tab') return unlinkTab();
    if (message.type === 'kindred-bridge-command') return {ok:false,connected:true,message:'Use the controls inside the shared page for interactive screen sharing.'};
    return { ok: false };
  })().then(sendResponse, error => sendResponse({ ok: false, message:error.message||'Tab control failed.' }));
  return true;
});

chrome.debugger.onDetach.addListener(async source=>{
  if((await interactive.restore())?.tabId===source.tabId){
    interactive.link=null; await chrome.storage.session.remove('interactiveLink');
    await clearLinkedTab(); await notifyKindredStatus({connected:false});
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  if (tabId === linkedTabId) unlinkTab();
});
chrome.webNavigation.onCommitted.addListener(async event=>{
  const link=await interactive.restore();
  if(link&&event.frameId===0&&(event.tabId===link.tabId||event.tabId===link.roomTabId))await unlinkTab();
});
