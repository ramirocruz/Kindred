(() => {
if (globalThis.__kindredBridgeInstalled) return;
globalThis.__kindredBridgeInstalled = true;

const KINDRED_CHANNEL = 'kindred-tab-control';

function postToKindred(type, payload) {
  window.postMessage({ channel: KINDRED_CHANNEL, type, payload }, location.origin);
}

function requestStatus() {
  chrome.runtime.sendMessage({ type: 'kindred-bridge-status' }, response => {
    if (chrome.runtime.lastError) return;
    postToKindred('interactive-bridge-status', response || { connected: false });
  });
}

window.addEventListener('message', event => {
  if (event.source !== window || event.origin !== location.origin) return;
  const message = event.data;
  if (!message || message.channel !== KINDRED_CHANNEL) return;
  if (message.type === 'interactive-status-request') {
    requestStatus();
    return;
  }
  if (message.type === 'playback-command') {
    chrome.runtime.sendMessage({ type: 'kindred-bridge-command', payload: message.payload || {} }, response => {
      if (chrome.runtime.lastError) return;
      if (response?.connected === false) postToKindred('interactive-bridge-status', response);
      postToKindred('command-result',{requestId:message.payload?.requestId,...response});
    });
  }
  if(message.type==='interactive-command'){
    chrome.runtime.sendMessage({type:'kindred-interactive',payload:message.payload},response=>{
      postToKindred('interactive-result',{requestId:message.payload?.requestId,...(chrome.runtime.lastError?{ok:false,message:chrome.runtime.lastError.message}:response)});
    });
  }
  if (message.type === 'interactive-unlink-tab') {
    chrome.runtime.sendMessage({ type: 'kindred-unlink-tab' }, response => {
      if (chrome.runtime.lastError) return;
      postToKindred('interactive-bridge-status', response || { connected: false });
    });
  }
});

chrome.runtime.onMessage.addListener(message => {
  if (message?.type === 'kindred-tab-event') postToKindred('tab-event', message.payload || {});
  if (message?.type === 'kindred-tab-bridge-status') postToKindred('interactive-bridge-status', message.payload || { connected: false });
});

requestStatus();
})();
